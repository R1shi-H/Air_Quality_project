#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string>
#include "aqi_crap.h"

#include "picojson.h"
#include <filesystem>
#include <unordered_map>

#define MULTI_THREAD

// {
//     "ID": 20,
//     "pm": 0,
//     "pm_cf_1": 0,
//     "pm_atm": 0,
//     "age": 0,
//     "pm_0": 0,
//     "pm_1": 0,
//     "pm_2": 0,
//     "pm_3": 0,
//     "pm_4": 0,
//     "pm_5": 0,
//     "pm_6": 0,
//     "conf": 97,
//     "pm1": 0,
//     "pm_10": 0,
//     "p1": 0,
//     "p2": 0,
//     "p3": 0,
//     "p4": 0,
//     "p5": 0,
//     "p6": 0,
//     "Humidity": null,
//     "Temperature": null,
//     "Pressure": null,
//     "Elevation": 1413,
//     "Type": 0,
//     "Label": "Oakdale",
//     "Lat": 40.603077,
//     "Lon": -111.83612,
//     "Icon": 0,
//     "isOwner": 0,
//     "Flags": 0,
//     "Voc": null,
//     "Ozone1": null,
//     "Adc": 0.01,
//     "CH": 1
// }

enum Keys
{ 
    ID,
    pm,
    pm_cf_1,
    pm_atm,
    age,
    pm_0,
    pm_1,
    pm_2,
    pm_3,
    pm_4,
    pm_5,
    pm_6,
    conf,
    pm1,
    pm_10,
    p1,
    p2,
    p3,
    p4,
    p5,
    p6,
    Humidity,
    Temperature,
    Pressure,
    Elevation,
    Type,
    Label,
    Lat,
    Lon,
    Icon,
    isOwner,
    Flags,
    Voc,
    Ozone1,
    Adc,
    CH,
};

struct Air_Quality_Sensor_Snapshot {
    int ID;
    float pm;
    // float pm_cf_1;
    // float pm_atm;
    // float age;
    // float pm_0;
    // float pm_1;
    // float pm_2;
    // float pm_3;
    // float pm_4;
    // float pm_5;
    // float pm_6;
    // float conf;
    // float pm1;
    // float pm_10;
    // float p1;
    // float p2;
    // float p3;
    // float p4;
    // float p5;
    // float p6;
    //float Humidity;
    //float Temperature;
    //float Pressure;
    //float Elevation;
    // float Type;
    float Lat;
    float Lon;
    std::string Label;
    // float Icon;
    // int isOwner;
    // int Flags;
    // float Voc;
    // float Ozone1;
    // float Adc;
    // float CH;
};

bool parse_air_quality_data(Air_Quality_Sensor_Snapshot* data, picojson::value data_table) {
    auto array_entry = data_table.get<picojson::array>();

    try
    {
        data->ID = (int)array_entry[ID].get<double>();
        data->pm = array_entry[pm].get<double>();
        data->Lat = array_entry[Lat].get<double>();
        data->Lon = array_entry[Lon].get<double>();
        data->Label = array_entry[Label].get<std::string>();
        return true;
    }
    catch (...)
    {
        return false;
    }
    //data.Humidity = array_entry[Humidity].get<double>();
    //data.Temperature = array_entry[Temperature].get<double>();
    //data.Elevation = array_entry[Elevation].get<double>();
}

std::string read_file(const std::string& path) {
    FILE* file;
    fopen_s(&file, path.c_str(), "rb");

    size_t file_size;
    uint8_t* file_data;

    fseek(file, 0, SEEK_END);
    file_size = ftell(file);
    file_data = (uint8_t*)malloc(file_size);

    fseek(file, 0, SEEK_SET);
    fread(file_data, 1, file_size, file);
    fclose(file);

    std::string string_data = std::string((char*)file_data, file_size);
    free(file_data);
    return string_data;
}





struct Air_Quality_Snapshot {
    std::unordered_map<int, Air_Quality_Sensor_Snapshot> sensors;
    std::vector<int> ids;
    int snapshot_id;
};


Air_Quality_Snapshot parse_air_quality_snapshot(const std::string& file) {
    picojson::value data_table;
    picojson::parse(data_table, file);

    picojson::array all_data = data_table.get("data").get<picojson::array>();

    Air_Quality_Snapshot aqi;
    for (uint32_t index = 0; index < all_data.size(); index++) {
        Air_Quality_Sensor_Snapshot aqis;
        if (parse_air_quality_data(&aqis, all_data[index])) {
            aqi.sensors[aqis.ID] = aqis;
            aqi.ids.push_back(aqis.ID);
        }
    }
    std::sort(aqi.ids.begin(), aqi.ids.end());

    return aqi;
}

int get_file_number(const std::string& data)
{
    int slash_pos = 0;
    for (int i = data.length() - 1; i >= 0; i--)
    {
        if (data[i] == '\\')
        {
            slash_pos = i;
            break;
        }
    }

    std::string str_end = data.substr(slash_pos + 1);
    str_end = str_end.substr(0, str_end.length() - 5);

    float file_num = std::atof(str_end.c_str());
    return file_num;
}

struct File_Entry
{
    int id;
    std::string data;
};

struct Raw_File_Data
{
    std::vector<File_Entry> entries;
};




#include <windows.h>

LONG measure_time()
{
    SYSTEMTIME time;
    GetSystemTime(&time);
    LONG time_ms = (time.wSecond * 1000) + time.wMilliseconds;
    return time_ms;
}

#include <thread>
#include <mutex>
#define THREAD_COUNT 12


void parse_thread(std::mutex* snapshot_mutex, std::vector<Air_Quality_Snapshot>* snapshots, Raw_File_Data* file_data, int offset)
{
    for (int i = offset; i < file_data->entries.size(); i += THREAD_COUNT)
    {
        LONG start = measure_time();

        auto& file_data_entry = file_data->entries[i];
        Air_Quality_Snapshot all_data = parse_air_quality_snapshot(file_data_entry.data);
        all_data.snapshot_id = file_data_entry.id;

        LONG end = measure_time();
        printf("Parse %d: %d\n", all_data.snapshot_id, end - start);

        {
            snapshot_mutex->lock();
            snapshots->push_back(all_data);
            snapshot_mutex->unlock();
        }
    }
}

#include <regex>
#include <sstream>

struct City {
    std::string city;
    std::string country;
    float lat;
    float lon;
};

std::vector<std::string> split_string(const std::string& str, const std::string& delim)
{
    using namespace std;
    vector<string> tokens;
    size_t prev = 0, pos = 0;
    do
    {
        pos = str.find(delim, prev);
        if (pos == string::npos) pos = str.length();
        string token = str.substr(prev, pos - prev);
        if (!token.empty()) tokens.push_back(token);
        prev = pos + delim.length();
    }
    while (pos < str.length() && prev < str.length());
    return tokens;
}

std::vector<City> parse_cities() {
    std::string city_file = read_file("World_Cities_Location_table.csv");
    std::stringstream strs;
    strs << city_file;

    std::vector<City> cities;

    std::string line;
    while (std::getline(strs, line)) {
        /*std::regex word = std::regex("\"");
        std::smatch results;
        bool a = std::regex_match(line, results, word);
        
        std::cout << (a ? "true" : "false") << std::endl;
        City city;
        city.city = results[1].str();
        city.country = results[2].str();
        city.lat = std::stof(results[3].str());
        city.lon = std::stof(results[4].str());
        cities.push_back(city);*/

        City city;
        std::vector<std::string> parts = split_string(line, ";");

        city.country = parts[1].substr(1, parts[1].length() - 2);
        city.city = parts[2].substr(1, parts[2].length() - 2);
        city.lat = std::stof(parts[3].substr(1, parts[3].length() - 2));
        city.lon = std::stof(parts[4].substr(1, parts[4].length() - 2));
        
        cities.push_back(city);
    }
    return cities;
}

City get_nearest_city(std::vector<City>& cities, float lat, float lon)
{
    float dist_sq = INFINITY;
    City close_city = cities[0];

    for (auto& city : cities)
    {
        float lat_dif = city.lat - lat;
        float lon_dif = city.lon - lon;
        float new_dist_sq = lat_dif * lat_dif + lon_dif * lon_dif;
        if (dist_sq > new_dist_sq)
        {
            dist_sq = new_dist_sq;
            close_city = city;
        }
    }

    //printf("Closest city to (%f, %f): %s @ %s(%f, %f)\n", lat, lon, close_city.city.c_str(), close_city.country.c_str(), close_city.lat, close_city.lon);

    return close_city;
}

void compute_thread(std::vector<Air_Quality_Snapshot>* snapshots, std::vector<City>* cities, std::map<std::string, float>* pm_values, std::map<std::string, float>* pm_samples, std::mutex* write_mutex, int offset)
{
    for (int i = offset; i < snapshots->size(); i += THREAD_COUNT)
    {
        auto& snapshot = *(snapshots->begin() + i);
        for (auto id : snapshot.ids)
        {
            Air_Quality_Sensor_Snapshot sensor = snapshot.sensors[id];
            //std::cout << snapshot.ID << " " << snapshot.Label << std::endl;
            City city = get_nearest_city(*cities, sensor.Lat, sensor.Lon);

            write_mutex->lock();
            (*pm_values)[city.country] += sensor.pm;
            (*pm_samples)[city.country] ++;
            write_mutex->unlock();
        }
        std::cout << "Snapshot " << snapshot.snapshot_id << " complete! (" << i << "/" << snapshots->size() << ")" << std::endl;
    }
}

void do_crap(
    std::map<std::string, float>& pm_values,
    std::map<std::string, float>& pm_samples,
    std::vector<City>& cities,
    Raw_File_Data file_data) {
    // C:\dev\crappy-science-project\purpleair\2021-02-08 21-32-13
    // 2021-02-08 22-00-22

    std::vector<Air_Quality_Snapshot> snapshots;

    std::cout << "Parsing..." << std::endl;

    #ifndef MULTI_THREAD
    for (int i = 0; i < file_data.entries.size(); i++)
    {
        LONG start = measure_time();

        auto& file_data_entry = file_data.entries[i];

        Air_Quality_Snapshot all_data = parse_air_quality_snapshot(file_data_entry.data);
        all_data.snapshot_id = file_data_entry.id;

        LONG end = measure_time();
        printf("Parse %d: %d\n", all_data.snapshot_id, end - start);

        {
            snapshots.push_back(all_data);
        }
    }
    #else
    {
        std::mutex snapshot_mutex;
        std::thread threads[THREAD_COUNT];
        for (int i = 0; i < THREAD_COUNT; i++)
            threads[i] = std::thread(parse_thread, &snapshot_mutex, &snapshots, &file_data, i);
        for (int i = 0; i < THREAD_COUNT; i++)
            threads[i].join();
    }
    #endif
    std::cout << "Done parsing!" << std::endl;


    #ifndef MULTI_THREAD
    {
        int snapshot_i = 0;
        for (auto& snapshot : snapshots)
        {
            snapshot_i++;
            for (auto id : snapshot.ids)
            {
                Air_Quality_Sensor_Snapshot sensor = snapshot.sensors[id];
                //std::cout << snapshot.ID << " " << snapshot.Label << std::endl;
                City city = get_nearest_city(cities, sensor.Lat, sensor.Lon);
                pm_values[city.country] += sensor.pm;
                pm_samples[city.country] ++;
            }
            std::cout << "Snapshot " << snapshot.snapshot_id << " complete! (" << snapshot_i << "/" << snapshots.size() << ")" << std::endl;
        }
    }
    #else
    {
        std::mutex write_mutex;

        std::thread threads[THREAD_COUNT];
        for (int i = 0; i < THREAD_COUNT; i++)
            threads[i] = std::thread(compute_thread, &snapshots, &cities, &pm_values, &pm_samples, &write_mutex, i);
        for (int i = 0; i < THREAD_COUNT; i++)
            threads[i].join();
    }
    #endif


    //for (int i = 0; i < file_data.entries.size(); i++)
    //{
    //    LONG start = measure_time();

    //    auto& file_data_entry = file_data.entries[i];

    //    Air_Quality_Snapshot all_data = parse_air_quality_snapshot(file_data_entry.data);
    //    all_data.snapshot_id = file_data_entry.id;

    //    LONG end = measure_time();
    //    printf("Parse: %d\n", end - start);

    //    {
    //        snapshots.push_back(all_data);
    //    }
    //} 
}


int main() {
    // "C:\\dev\\crappy-science-project\\purpleair\\2021-02-08 22-00-22\\0.json"


    std::cout << "Loading cities..." << std::endl;
    std::vector<City> cities = parse_cities();
    std::cout << "Done loading cities..." << std::endl;

    std::string load_path = "C:\\dev\\crappy-science-project\\purpleair\\2021-02-09 16-59-51";
    auto file_it = std::filesystem::directory_iterator(load_path);

    std::map<std::string, float> pm_values;
    std::map<std::string, float> pm_samples;


    int pass_size = 200;

    // pass count
    int total_iters = 0;
    int total_passes = 0;
    {
        auto it_clone = std::filesystem::directory_iterator(load_path);
        for (auto& i : it_clone)
            total_iters++;
        total_passes = ceil(total_iters / (float)pass_size);
    }

    int pass_index = 0;

    while (!file_it._At_end())
    {
        std::cout << "(Pass:" << pass_index << "/" << total_passes << ") Loading air info..." << std::endl;
        Raw_File_Data file_data;
        for (int i = 0; i < pass_size && (!file_it._At_end()); i++)
        {
            auto file_path = (*file_it).path();
            std::string file_str = read_file(file_path.string());
            //printf("%d\n", get_file_number(file_path.string()));

            File_Entry file;
            file.id = get_file_number(file_path.string());
            file.data = file_str;
            file_data.entries.push_back(file);

            file_it++;
        }
        std::cout << "(Pass:" << pass_index << "/" << total_passes << ") Done loading air info!" << std::endl;
        pass_index++;
        std::cout << "Starting pass " << pass_index << "/" << total_passes << std::endl;
        do_crap(pm_values, pm_samples, cities, file_data);
        std::cout << "Ending pass " << pass_index << "/" << total_passes << std::endl;
    }


    std::stringstream file_data_output;
    file_data_output << "Country,Average AQI" << std::endl;
    for (auto& it : pm_values)
    {
        float value = it.second;
        float samples = pm_samples[it.first];
        file_data_output << it.first << "," << aqiFromPM(value / samples) << std::endl;
    }

    std::cout << "Done! Writing data to file..." << std::endl;
    {
        // write our data
        std::string buffer = file_data_output.str();
        FILE* file;
        fopen_s(&file, "data.csv", "wb");
        fwrite(buffer.data(), 1, buffer.length(), file);
        fclose(file);
    }
    std::cout << "Done! Yeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" << std::endl;

    return 0;
}
