# Crap
Eto crapski

## Developers
- Sean (COVID-19 + Air Quality)
- Rishi (Countries + Air Quality)
